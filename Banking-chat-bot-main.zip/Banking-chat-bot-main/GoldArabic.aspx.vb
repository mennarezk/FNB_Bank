﻿
Partial Class GoldArabic
    Inherits System.Web.UI.Page

End Class
