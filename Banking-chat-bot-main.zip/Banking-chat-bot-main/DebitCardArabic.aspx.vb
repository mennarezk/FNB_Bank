﻿
Partial Class DebitCardArabic
    Inherits System.Web.UI.Page

End Class
