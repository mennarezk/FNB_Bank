﻿
Partial Class Gold
    Inherits System.Web.UI.Page

End Class
