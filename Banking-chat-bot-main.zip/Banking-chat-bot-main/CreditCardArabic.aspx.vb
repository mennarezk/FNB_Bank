﻿
Partial Class CreditCardArabic
    Inherits System.Web.UI.Page

End Class
