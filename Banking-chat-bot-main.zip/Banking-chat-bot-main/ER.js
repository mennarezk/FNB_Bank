﻿var rate = 0.02;
const url = `https://v6.exchangerate-api.com/v6/1877bbf1b10456b7f8d2b670/latest/EGP`;
fetch(url)
    .then(response => response.json())
    .then(data => {

        document.getElementById("usd2").textContent = data.conversion_rates.USD + rate.toFixed(2);
        document.getElementById("qar2").textContent = data.conversion_rates.QAR + rate.toFixed(2);
        document.getElementById("jod2").textContent = data.conversion_rates.JOD + rate.toFixed(2);
        document.getElementById("aud2").textContent = data.conversion_rates.AUD + rate.toFixed(2);
        document.getElementById("eur2").textContent = data.conversion_rates.EUR + rate.toFixed(2);
        document.getElementById("cad2").textContent = data.conversion_rates.CAD + rate.toFixed(2);
        document.getElementById("iqd2").textContent = data.conversion_rates.IQD + rate.toFixed(2);
        document.getElementById("sek2").textContent = data.conversion_rates.SEK + rate.toFixed(2);
        document.getElementById("inr2").textContent = data.conversion_rates.INR + rate.toFixed(2);
        document.getElementById("mur2").textContent = data.conversion_rates.MUR + rate.toFixed(2);


        document.getElementById("usd").textContent = data.conversion_rates.USD.toFixed(2);
        document.getElementById("qar").textContent = data.conversion_rates.QAR.toFixed(2);
        document.getElementById("jod").textContent = data.conversion_rates.JOD.toFixed(2);
        document.getElementById("aud").textContent = data.conversion_rates.AUD.toFixed(2);
        document.getElementById("eur").textContent = data.conversion_rates.EUR.toFixed(2);
        document.getElementById("cad").textContent = data.conversion_rates.CAD.toFixed(2);
        document.getElementById("iqd").textContent = data.conversion_rates.IQD.toFixed(2);
        document.getElementById("sek").textContent = data.conversion_rates.SEK.toFixed(2);
        document.getElementById("inr").textContent = data.conversion_rates.INR.toFixed(2);
        document.getElementById("mur").textContent = data.conversion_rates.MUR.toFixed(2);
    })


    .catch(error => console.error(error));