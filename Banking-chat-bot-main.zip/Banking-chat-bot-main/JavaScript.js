﻿let currencies = [
    "AED",
    "AFN",
 
];
