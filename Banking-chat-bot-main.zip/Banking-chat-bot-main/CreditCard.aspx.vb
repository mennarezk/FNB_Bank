﻿
Partial Class CreditCard
    Inherits System.Web.UI.Page

End Class
