﻿
Partial Class CardsArabic
    Inherits System.Web.UI.Page

End Class
