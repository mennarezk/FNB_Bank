﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }



  

    //protected void TextBox1_TextChanged1(object sender, EventArgs e)
    //{
    //    if (TextBox1.Text == "Debit Cards")
    //    {
    //        Response.Redirect("DebitCard.aspx");
    //    }
    //    else if (TextBox1.Text == "Debit")
    //    {
    //        Response.Redirect("DebitCard.aspx");
    //    }
    //    else if (TextBox1.Text == "debit card")
    //    {
    //        Response.Redirect("DebitCard.aspx");
    //    }
    //    else if (TextBox1.Text == "debit cards")
    //    {
    //        Response.Redirect("DebitCard.aspx");
    //    }
    //    // credit card 
    //    else if (TextBox1.Text == "Credit Cards")
    //    {
    //        Response.Redirect("CreditCard.aspx");
    //    }
    //    else if (TextBox1.Text == "Credit")
    //    {
    //        Response.Redirect("CreditCard.aspx");
    //    }
    //    else if (TextBox1.Text == "credit cards")
    //    {
    //        Response.Redirect("CreditCard.aspx");
    //    }
    //    else if (TextBox1.Text == "credit card")
    //    {
    //        Response.Redirect("CreditCard.aspx");
    //    }
    //    // visa gold
    //    else if (TextBox1.Text == "Visa Gold")
    //    {
    //        Response.Redirect("Gold.aspx");
    //    }
    //    else if (TextBox1.Text == "Visa")
    //    {
    //        Response.Redirect("Gold.aspx");
    //    }
    //    else if (TextBox1.Text == "visa gold")
    //    {
    //        Response.Redirect("Gold.aspx");
    //    }

    //    // Ceritificates Platinum Certificate 3 years
    //    else if (TextBox1.Text == "Platinum Certificate 3 Years")
    //    {
    //        Response.Redirect("Platinum Certificate 3 years1.aspx");
    //    }
    //    else if (TextBox1.Text == "Platinum Certificate")
    //    {
    //        Response.Redirect("Platinum Certificate 3 years1.aspx");
    //    }
    //    else if (TextBox1.Text == "platinum certificate")
    //    {
    //        Response.Redirect("Platinum Certificate 3 years1.aspx");
    //    }
    //    else if (TextBox1.Text == "Platinum certificate")
    //    {
    //        Response.Redirect("Platinum Certificate 3 years1.aspx");
    //    }
    //    // Ceritificates Platinum variable interest
    //    else if (TextBox1.Text == "Platinum Variable Interest")
    //    {
    //        Response.Redirect("Platinum Certificate 3 years2.aspx");
    //    }
    //    else if (TextBox1.Text == "platinum variable interest")
    //    {
    //        Response.Redirect("Platinum Certificate 3 years2.aspx");
    //    }
    //    else if (TextBox1.Text == "Platinum Variable ")
    //    {
    //        Response.Redirect("Platinum Certificate 3 years2.aspx");
    //    }
    //    else if (TextBox1.Text == "Platinum variable ")
    //    {
    //        Response.Redirect("Platinum Certificate 3 years2.aspx");
    //    }
    //    //Ceritificates Five Years CD.aspx
    //    else if (TextBox1.Text == "Five Years CD")
    //    {
    //        Response.Redirect("Platinum Certificate 3 years3.aspx");
    //    }
    //    else if (TextBox1.Text == "Five Years  ")
    //    {
    //        Response.Redirect("Platinum Certificate 3 years3.aspx");
    //    }
    //    else if (TextBox1.Text == "five years")
    //    {
    //        Response.Redirect("Platinum Certificate 3 years3.aspx");
    //    }
    //    else if (TextBox1.Text == "Five years")
    //    {
    //        Response.Redirect("Platinum Certificate 3 years3.aspx");
    //    }
    //    else if (TextBox1.Text == "five year")
    //    {
    //        Response.Redirect("Platinum Certificate 3 years3.aspx");
    //    }
    //    else if (TextBox1.Text == "Five Year")
    //    {
    //        Response.Redirect("Platinum Certificate 3 years3.aspx");
    //        //current account
    //    }
    //    else if (TextBox1.Text == "current account")
    //    {
    //        Response.Redirect("CurrentAccount.aspx");
    //    }
    //    else if (TextBox1.Text == "Current Account")
    //    {
    //        Response.Redirect("CurrentAccount.aspx");
    //    }
    //    else if (TextBox1.Text == "current")
    //    {
    //        Response.Redirect("CurrentAccount.aspx");
    //    }
    //    else if (TextBox1.Text == "Current")
    //    {
    //        Response.Redirect("CurrentAccount.aspx");
    //    }
    //    //saving account
    //    else if (TextBox1.Text == "saving account")
    //    {
    //        Response.Redirect("SavingAccount.aspx");
    //    }
    //    else if (TextBox1.Text == "Saving Account")
    //    {
    //        Response.Redirect("SavingAccount.aspx");
    //    }
    //    else if (TextBox1.Text == "saving")
    //    {
    //        Response.Redirect("SavingAccount.aspx");
    //    }
    //    else if (TextBox1.Text == "Saving")
    //    {
    //        Response.Redirect("SavingAccount.aspx");
    //    }
    //    //loan amount
    //    else if (TextBox1.Text == "loan")
    //    {
    //        Response.Redirect("LoanAmount.aspx");
    //    }
    //    else if (TextBox1.Text == "loan amount")
    //    {
    //        Response.Redirect("LoanAmount.aspx");
    //    }
    //    else if (TextBox1.Text == "Loan")
    //    {
    //        Response.Redirect("LoanAmount.aspx");
    //    }
    //    else if (TextBox1.Text == "Loan Amount")
    //    {
    //        Response.Redirect("LoanAmount.aspx");
    //    }

    //    //time deposit
    //    else if (TextBox1.Text == "time" || (TextBox1.Text == "Time"))
    //    {
    //        Response.Redirect("TimeDeposit.aspx");
    //    }
    //    else if (TextBox1.Text == "time deposit" || (TextBox1.Text == "Time Deposit"))
    //    {
    //        Response.Redirect("TimeDeposit.aspx");
    //    }
    //    else if (TextBox1.Text == "Deposit" || TextBox1.Text == "deposit")
    //    {
    //        Response.Redirect("TimeDeposit.aspx");
    //    }
    //    //time deposit cal
    //    else if (TextBox1.Text == "time calculator" || (TextBox1.Text == "Time Calculator"))
    //    {
    //        Response.Redirect("TimeDebositCal.aspx");
    //    }
    //    else if (TextBox1.Text == "time deposit calculator" || (TextBox1.Text == "Time Deposit Calculator"))
    //    {
    //        Response.Redirect("TimeDebositCal.aspx");
    //    }
    //    else if (TextBox1.Text == "Deposit calculator" || TextBox1.Text == "deposit calculator")
    //    {
    //        Response.Redirect("TimeDebositCal.aspx");
    //    }
    //    //currency convert
    //    else if (TextBox1.Text == "currency convert" || (TextBox1.Text == "Currency Convert"))
    //    {
    //        Response.Redirect("Currencyonvert.aspx");
    //    }
    //    else if (TextBox1.Text == "currency" || (TextBox1.Text == "Currency "))
    //    {
    //        Response.Redirect("Currencyonvert.aspx");
    //    }
    //    //exchange rate
    //    else if (TextBox1.Text == "exchange rate" || (TextBox1.Text == "Exchange Rate") || (TextBox1.Text == "Exchange") || (TextBox1.Text == "Exchange currency"))
    //    {
    //        Response.Redirect("ExchangeRate.aspx");
    //    }

    //}
}
